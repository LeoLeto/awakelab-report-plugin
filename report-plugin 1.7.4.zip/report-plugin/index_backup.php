<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main entry point for the question bank report.
 *
 * @package    report_questionbank
 * @copyright  2025 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');
require_once($CFG->libdir.'/adminlib.php');

// Load plugin version information
require_once($CFG->dirroot . '/report/questionbank/version.php');

// Get the course ID from the URL parameter.
$courseid = required_param('id', PARAM_INT);
$categoryids = optional_param_array('categoryids', array(), PARAM_INT);
$download = optional_param('download', '', PARAM_ALPHA);
$finalexamcategoryid = optional_param('finalexamcategoryid', 0, PARAM_INT);

// If a unit is selected as final exam, ensure it's included in the categories
if ($finalexamcategoryid > 0 && !in_array($finalexamcategoryid, $categoryids)) {
    $categoryids[] = $finalexamcategoryid;
}

// Get the course and ensure user is logged in.
$course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
require_login($course);

// Check capabilities.
$context = context_course::instance($courseid);
require_capability('report/questionbank:view', $context);

// Set up the page.
$PAGE->set_url('/report/questionbank/index.php', array('id' => $courseid));
$PAGE->set_context($context);
$PAGE->set_title(get_string('title', 'report_questionbank'));
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('report');

// Add CSS.
$PAGE->requires->css('/report/questionbank/styles.css');

// Get question categories for this course.
// Exclude the root "Top" category by filtering parent = 0
$categories = $DB->get_records_sql(
    "SELECT qc.* 
     FROM {question_categories} qc
     WHERE qc.contextid = :contextid
     AND qc.parent != 0
     ORDER BY qc.name",
    array('contextid' => $context->id)
);

// Build query to get questions - compatible with Moodle 4.0+
$sql = "SELECT q.id, q.name, q.questiontext, q.qtype, qc.name as categoryname, qbe.questioncategoryid
        FROM {question} q
        JOIN {question_versions} qv ON qv.questionid = q.id
        JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
        JOIN {question_categories} qc ON qc.id = qbe.questioncategoryid
        WHERE qc.contextid = :contextid
        AND qv.version = (SELECT MAX(version) FROM {question_versions} WHERE questionbankentryid = qbe.id)";

$params = array('contextid' => $context->id);

if (!empty($categoryids)) {
    list($insql, $inparams) = $DB->get_in_or_equal($categoryids, SQL_PARAMS_NAMED);
    $sql .= " AND qc.id $insql";
    $params = array_merge($params, $inparams);
}

$sql .= " ORDER BY qc.name, q.name";

$questions = $DB->get_records_sql($sql, $params);

// Get quizzes and their random question counts for this course
$quizzes_sql = "SELECT q.id, q.name, 
                COUNT(DISTINCT qrs.id) as random_count
                FROM {quiz} q
                LEFT JOIN {quiz_slots} qs ON qs.quizid = q.id
                LEFT JOIN {question_set_references} qsr ON qsr.itemid = qs.id AND qsr.component = 'mod_quiz' AND qsr.questionarea = 'slot'
                LEFT JOIN {question_references} qr ON qr.itemid = qs.id AND qr.component = 'mod_quiz' AND qr.questionarea = 'slot'
                LEFT JOIN {question_set_references} qrs ON qrs.itemid = qs.id AND qrs.component = 'mod_quiz' AND qrs.questionarea = 'slot'
                WHERE q.course = :courseid
                GROUP BY q.id, q.name
                ORDER BY q.name";
$quizzes = $DB->get_records_sql($quizzes_sql, array('courseid' => $courseid));

// Handle Excel download.
if ($download === 'excel') {
    require_once($CFG->dirroot . '/report/questionbank/classes/excel_export.php');
    $exporter = new \report_questionbank\excel_export();
    $exporter->export_questions($questions, $course->shortname);
    exit;
}

// Handle PDF download.
if ($download === 'pdf') {
    require_once($CFG->dirroot . '/report/questionbank/classes/pdf_export.php');
    $exporter = new \report_questionbank\pdf_export();
    $exporter->export_questions($questions, $course->shortname, $finalexamcategoryid);
    exit;
}

// Output page.
echo $OUTPUT->header();

// Add inline CSS
echo '<style>
.question-bank-filters {
    margin: 20px 0;
    padding: 15px;
    background-color: #f5f5f5;
    border-radius: 5px;
    display: block;
    clear: both;
}
.question-bank-filters label {
    font-weight: bold;
    margin-right: 10px;
}
.question-bank-filters select {
    padding: 5px 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
    font-size: 14px;
}
.download-button-container {
    margin: 20px 0;
    text-align: right;
    display: block;
    clear: both;
}
.question-bank-table-container {
    margin: 20px 0;
    overflow-x: auto;
    display: block;
    clear: both;
    width: 100%;
}
.question-bank-table {
    width: auto !important;
    min-width: 100%;
    border-collapse: collapse;
    display: block !important;
}
.question-bank-table thead {
    display: block !important;
    width: 100%;
}
.question-bank-table tbody {
    display: block !important;
    width: 100%;
}
.question-bank-table tr {
    display: table !important;
    width: 100%;
    table-layout: fixed;
}
.question-bank-table th,
.question-bank-table td {
    display: table-cell !important;
    word-wrap: break-word;
}
.question-bank-table th:nth-child(1),
.question-bank-table td:nth-child(1) {
    width: 30%;
}
.question-bank-table th:nth-child(2),
.question-bank-table td:nth-child(2) {
    width: 10%;
}
.question-bank-table th:nth-child(3),
.question-bank-table td:nth-child(3) {
    width: 20%;
}
.question-bank-table th:nth-child(4),
.question-bank-table td:nth-child(4) {
    width: 40%;
}
.question-bank-table th {
    background-color: #0f6cbf;
    color: white;
    padding: 12px;
    text-align: left;
    font-weight: bold;
    border: 1px solid #0a5291;
}
.question-bank-table td {
    padding: 10px;
    border: 1px solid #ddd;
    vertical-align: top;
    background-color: #fff;
}
.question-bank-table tbody tr:hover {
    background-color: #f5f5f5;
}
.question-bank-table tbody tr:hover td {
    background-color: #f5f5f5;
}
.question-answers-list {
    margin: 0;
    padding-left: 20px;
    list-style-type: disc;
}
.question-answers-list li {
    margin: 5px 0;
}
</style>';

echo $OUTPUT->heading(get_string('title', 'report_questionbank'));

// Display version label
echo '<div style="text-align: right; margin-bottom: 10px; color: #666; font-size: 12px;">';
echo 'Versión: ' . $plugin->release;
echo '</div>';

echo '<script type="text/javascript">';
echo 'function updateIncludeCheckboxes() {';
echo '    var checkboxes = document.querySelectorAll(".category-checkbox");';
echo '    ';
echo '    checkboxes.forEach(function(checkbox) {';
echo '        var tr = checkbox.closest("tr");';
echo '        if (!tr) return;';
echo '        var rowRadio = tr.querySelector(".final-exam-radio");';
echo '        var shouldDisable = rowRadio && rowRadio.checked;';
echo '        ';
echo '        if (shouldDisable) {';
echo '            checkbox.disabled = true;';
echo '            checkbox.checked = false;';
echo '            checkbox.style.opacity = "0.5";';
echo '            checkbox.style.cursor = "not-allowed";';
echo '            checkbox.style.pointerEvents = "none";';
echo '        } else {';
echo '            checkbox.disabled = false;';
echo '            checkbox.style.opacity = "1";';
echo '            checkbox.style.cursor = "auto";';
echo '            checkbox.style.pointerEvents = "auto";';
echo '        }';
echo '    });';
echo '}';
echo '';
echo '// Radio-button behavior for final exam selection';
echo 'document.addEventListener("DOMContentLoaded", function() {';
echo '    var finalExamRadios = document.querySelectorAll(".final-exam-radio");';
echo '    var categoryCheckboxes = document.querySelectorAll(".category-checkbox");';
echo '    ';
echo '    finalExamRadios.forEach(function(radio) {';
echo '        radio.addEventListener("change", function() {';
echo '            if (this.checked) {';
echo '                finalExamRadios.forEach(function(r) {';
echo '                    if (r !== radio) {';
echo '                        r.checked = false;';
echo '                    }';
echo '                });';
echo '            }';
echo '            updateIncludeCheckboxes();';
echo '        });';
echo '    });';
echo '    ';
echo '    // Prevent changes to disabled checkboxes';
echo '    categoryCheckboxes.forEach(function(checkbox) {';
echo '        checkbox.addEventListener("click", function(e) {';
echo '            if (this.disabled) {';
echo '                e.preventDefault();';
echo '                e.stopPropagation();';
echo '                return false;';
echo '            }';
echo '        });';
echo '        checkbox.addEventListener("change", function(e) {';
echo '            if (this.disabled) {';
echo '                e.preventDefault();';
echo '                this.checked = false;';
echo '                return false;';
echo '            }';
echo '        });';
echo '    });';
echo '    ';
echo '    updateIncludeCheckboxes();';
echo '});';
echo '</script>';

// Category filter.
echo '<div class="question-bank-filters" id="filterSection" style="display: block;">';
echo '<form method="get" action="index.php" id="categoryFilterForm">';
echo '<input type="hidden" name="id" value="' . $courseid . '" />';
echo '<div style="margin-bottom: 20px;">';
echo '<label style="font-weight: bold; display: block; margin-bottom: 12px; font-size: 16px;">' . get_string('filterbycategory', 'report_questionbank') . ':</label>';

// If no categories selected, select all by default
$all_selected = empty($categoryids);

// Display units in a table format
echo '<table class="generaltable" style="width: 100%; background-color: white; margin-bottom: 15px;">';
echo '<thead>';
echo '<tr>';
echo '<th style="padding: 10px; text-align: left;">' . get_string('unitname', 'report_questionbank') . '</th>';
echo '<th style="padding: 10px; text-align: center; width: 150px;">Incluir</th>';
echo '<th style="padding: 10px; text-align: center; width: 200px;">' . get_string('selectasfinalexam', 'report_questionbank') . '</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

foreach ($categories as $cat) {
    $is_selected = ($all_selected || in_array($cat->id, $categoryids));
    $is_final_exam = ($finalexamcategoryid > 0 && $cat->id == $finalexamcategoryid);
    
    // If this row is selected as final exam, don't check and disable the include checkbox
    $checkbox_checked = $is_selected && !$is_final_exam;
    $checkbox_disabled = $is_final_exam ? 'disabled' : '';
    
    echo '<tr>';
    echo '<td style="padding: 10px;">' . format_string($cat->name) . '</td>';
    echo '<td style="padding: 10px; text-align: center;">';
    echo '<input type="checkbox" class="category-checkbox" name="categoryids[]" value="' . $cat->id . '" ' . ($checkbox_checked ? 'checked' : '') . ' ' . $checkbox_disabled . '>';
    echo '</td>';
    echo '<td style="padding: 10px; text-align: center;">';
    echo '<input type="radio" class="final-exam-radio" name="finalexamcategoryid" value="' . $cat->id . '" ' . ($is_final_exam ? 'checked' : '') . '>';
    echo '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';

echo '<div style="display: flex; gap: 10px;">';
echo '<button type="button" id="selectAllBtn" class="btn btn-outline-secondary">Seleccionar todas las unidades</button>';
echo '<button type="submit" class="btn btn-outline-primary" style="display: none;">Aplicar filtro</button>';
echo '</div>';
echo '</div>';
echo '</form>';
echo '</div>';

echo '<script type="text/javascript">';
echo 'document.addEventListener("DOMContentLoaded", function() {';
echo '    var form = document.getElementById("categoryFilterForm");';
echo '    var categoryCheckboxes = document.querySelectorAll(".category-checkbox");';
echo '    var finalExamRadios = document.querySelectorAll(".final-exam-radio");';
echo '    ';
echo '    function autoSubmitForm() {';
echo '        if (form) {';
echo '            form.submit();';
echo '        }';
echo '    }';
echo '    ';
echo '    categoryCheckboxes.forEach(function(checkbox) {';
echo '        checkbox.addEventListener("change", autoSubmitForm);';
echo '    });';
echo '    ';
echo '    finalExamRadios.forEach(function(radio) {';
echo '        radio.addEventListener("change", autoSubmitForm);';
echo '    });';
echo '    ';
echo '    // Before form submission, ensure final exam unit is included in categoryids';
echo '    if (form) {';
echo '        form.addEventListener("submit", function(e) {';
echo '            var selectedFinalExam = Array.from(finalExamRadios).find(function(r) { return r.checked; });';
echo '            if (selectedFinalExam) {';
echo '                var finalExamValue = selectedFinalExam.value;';
echo '                var finalExamHidden = form.querySelector("input[name=\"finalexamcategoryid\"]");';
echo '                if (!finalExamHidden) {';
echo '                    finalExamHidden = document.createElement("input");';
echo '                    finalExamHidden.type = "hidden";';
echo '                    finalExamHidden.name = "finalexamcategoryid";';
echo '                    form.appendChild(finalExamHidden);';
echo '                }';
echo '                finalExamHidden.value = finalExamValue;';
echo '                var isFinalExamIncluded = Array.from(categoryCheckboxes).some(function(cb) { return cb.value == finalExamValue && cb.checked; });';
echo '                if (!isFinalExamIncluded) {';
echo '                    var hiddenCheckbox = document.createElement("input");';
echo '                    hiddenCheckbox.type = "hidden";';
echo '                    hiddenCheckbox.name = "categoryids[]";';
echo '                    hiddenCheckbox.value = finalExamValue;';
echo '                    form.appendChild(hiddenCheckbox);';
echo '                }';
echo '            }';
echo '        });';
echo '    }';
echo '});';
echo '</script>';

echo '<style>';
echo '.final-exam-checkbox:disabled {';
echo '    opacity: 0.5;';
echo '    cursor: not-allowed;';
echo '}';
echo '.category-checkbox:disabled {';
echo '    pointer-events: none;';
echo '    opacity: 0.5;';
echo '    cursor: not-allowed;';
echo '}';
echo '</style>';

// Build download button parameters for use in multiple places
$categoryparams = '';
if (!empty($questions)) {
    foreach ($categoryids as $catid) {
        $categoryparams .= '&categoryids[]=' . $catid;
    }
    if ($finalexamcategoryid > 0) {
        $categoryparams .= '&finalexamcategoryid=' . $finalexamcategoryid;
    }
}

// Download button - placed before quiz info
if (!empty($questions)) {
    echo '<div class="download-button-container">';
    echo '<a href="index.php?id=' . $courseid . $categoryparams . '&download=pdf" class="btn btn-primary" style="margin-right: 10px;">';
    echo get_string('downloadpdf', 'report_questionbank');
    echo '</a>';
    echo '<a href="index.php?id=' . $courseid . $categoryparams . '&download=excel" class="btn btn-secondary" id="excelButton" style="display: none !important;">';
    echo get_string('downloadexcel', 'report_questionbank');
    echo '</a>';
    echo '</div>';
}

// Quiz information section
if (!empty($quizzes)) {
    echo '<div class="quiz-info-section" id="quizInfoSection" style="display: block; margin-top: 20px; padding: 15px; background-color: #f9f9f9; border-radius: 5px; border: 1px solid #ddd;">';
    echo '<h4 style="margin-top: 0; color: #0f6cbf;">' . get_string('quizinformation', 'report_questionbank') . '</h4>';
    echo '<table class="generaltable" style="width: 100%; background-color: white;">';
    echo '<thead>';
    echo '<tr>';
    echo '<th style="padding: 10px; text-align: left;">' . get_string('quizname', 'report_questionbank') . '</th>';
    echo '<th style="padding: 10px; text-align: center; width: 200px;">' . get_string('questioncount', 'report_questionbank') . '</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($quizzes as $quiz) {
        // Count total questions in this quiz (including random questions)
        $slot_count_sql = "SELECT COUNT(*) as total 
                          FROM {quiz_slots} 
                          WHERE quizid = :quizid";
        $slot_count = $DB->get_record_sql($slot_count_sql, array('quizid' => $quiz->id));
        $total_questions = $slot_count ? $slot_count->total : 0;
        
        echo '<tr>';
        echo '<td style="padding: 10px;">' . format_string($quiz->name) . '</td>';
        echo '<td style="padding: 10px; text-align: center; font-weight: bold;">' . $total_questions . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

// Display questions.
if (empty($questions)) {
    echo '<p>' . get_string('noquestions', 'report_questionbank') . '</p>';
} else {
    echo '<h3 style="margin-top: 30px; margin-bottom: 15px; color: #0f6cbf;">Vista previa de las preguntas a incluir</h3>';
    echo '<div class="question-bank-table-container">';
    echo '<table class="generaltable question-bank-table">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>' . get_string('questiontext', 'report_questionbank') . '</th>';
    echo '<th>' . get_string('questiontype', 'report_questionbank') . '</th>';
    echo '<th>' . get_string('category', 'report_questionbank') . '</th>';
    echo '<th>' . get_string('answers', 'report_questionbank') . '</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    
    foreach ($questions as $question) {
        echo '<tr>';
        echo '<td>' . strip_tags($question->questiontext) . '</td>';
        echo '<td>' . format_string($question->qtype) . '</td>';
        echo '<td>' . format_string($question->categoryname) . '</td>';
        
        // Get answers for this question.
        $answers = $DB->get_records('question_answers', array('question' => $question->id));
        echo '<td>';
        if (!empty($answers)) {
            echo '<ul class="question-answers-list">';
            foreach ($answers as $answer) {
                $correct = ($answer->fraction > 0) ? ' (✓)' : '';
                echo '<li>' . format_text($answer->answer, FORMAT_HTML) . $correct . '</li>';
            }
            echo '</ul>';
        } else {
            echo '<em>No answers</em>';
        }
        echo '</td>';
        echo '</tr>';
    }
    
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

echo '<script type="text/javascript">';
echo '(function() {';
echo '    var categoryCheckboxes = document.querySelectorAll(".category-checkbox");';
echo '    var selectAllBtn = document.getElementById("selectAllBtn");';
echo '    var form = document.getElementById("categoryFilterForm");';
echo '    if (selectAllBtn && categoryCheckboxes.length > 0) {';
echo '        selectAllBtn.addEventListener("click", function() {';
echo '            var allChecked = Array.from(categoryCheckboxes).every(function(cb) { return cb.checked; });';
echo '            categoryCheckboxes.forEach(function(cb) {';
echo '                cb.checked = !allChecked;';
echo '            });';
echo '        });';
echo '    }';
echo '    ';
echo '})();';
echo '</script>';

echo $OUTPUT->footer();
